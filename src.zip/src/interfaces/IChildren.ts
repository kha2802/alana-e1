export default interface IChildren {
    children: React.ReactNode
}
export interface IChildrens {
    children: React.ReactNode[]
}