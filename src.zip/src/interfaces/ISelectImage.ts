export interface ISelectImage{
    name:string,
    value:string,
    group:string,
    type:string
}