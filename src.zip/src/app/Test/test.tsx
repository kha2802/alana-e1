export default function TestPage() {
  return (
    <main style={{ padding: '20px' }}>
      <h1>Trang Test thành công</h1>
      <p>Nếu bạn nhìn thấy trang này, Next.js đang hoạt động ổn.</p>
    </main>
  );
}
